package main.application_oop.model;

public class BreedInfo {
    private String name;
    private String species;
    private String origin;
    private String personality;
    private double averagePrice;
    private int quantity;

    public BreedInfo(String name, String species, String origin, String personality, double averagePrice, int quantity) {
        this.name = name;
        this.species = species;
        this.origin = origin;
        this.personality = personality;
        this.averagePrice = averagePrice;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getPersonality() {
        return personality;
    }

    public void setPersonality(String personality) {
        this.personality = personality;
    }

    public double getAveragePrice() {
        return averagePrice;
    }

    public void setAveragePrice(double averagePrice) {
        this.averagePrice = averagePrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalValue() {
        return averagePrice * quantity;
    }
}
