package main.application_oop.model;

public class Product {
    private String id;
    private String name;
    private String category;
    private String petType;
    private double price;
    private int stock;

    public Product(String id, String name, String category, String petType, double price, int stock) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.petType = petType;
        this.price = price;
        this.stock = stock;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public double getTotalValue() {
        return price * stock;
    }
}
