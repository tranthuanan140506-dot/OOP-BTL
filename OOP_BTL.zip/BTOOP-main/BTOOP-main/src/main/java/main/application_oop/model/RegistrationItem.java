package main.application_oop.model;

public class RegistrationItem {
    private final String offeringType;
    private final String offeringName;
    private final double price;

    public RegistrationItem(String offeringType, String offeringName, double price) {
        this.offeringType = offeringType;
        this.offeringName = offeringName;
        this.price = price;
    }

    public String getOfferingType() {
        return offeringType;
    }

    public String getOfferingName() {
        return offeringName;
    }

    public double getPrice() {
        return price;
    }
}
