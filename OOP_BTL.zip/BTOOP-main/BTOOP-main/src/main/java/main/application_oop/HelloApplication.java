package main.application_oop;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        var resource = HelloApplication.class.getResource("/view/login-view.fxml");
        if (resource == null) {
            throw new IllegalStateException("Khong tim thay file FXML: /view/login-view.fxml");
        }

        FXMLLoader fxmlLoader = new FXMLLoader(resource);
        Scene scene = new Scene(fxmlLoader.load(), 520, 420);
        scene.getStylesheets().add(HelloApplication.class.getResource("/view/app.css").toExternalForm());

        stage.setTitle("Dang nhap");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
