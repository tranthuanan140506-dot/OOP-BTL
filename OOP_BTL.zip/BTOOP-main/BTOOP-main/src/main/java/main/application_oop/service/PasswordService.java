package main.application_oop.service;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import main.application_oop.model.PasswordEntry;
import main.application_oop.model.PasswordRepository;

public class PasswordService {
    private final PasswordRepository repository = new PasswordRepository();

    public ObservableList<PasswordEntry> getAll() {
        return repository.findAll();
    }

    public void addPassword(String serviceName, String username, String password, String note) {
        repository.add(new PasswordEntry(serviceName, username, password, note));
    }

    public void updatePassword(PasswordEntry selected, String serviceName, String username, String password, String note) {
        if (selected == null) return;
        selected.setServiceName(serviceName);
        selected.setUsername(username);
        selected.setPassword(password);
        selected.setNote(note);
        repository.saveToFile();
    }

    public void deletePassword(PasswordEntry selected) {
        if (selected == null) return;
        repository.remove(selected);
    }

    public ObservableList<PasswordEntry> search(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return getAll();
        }

        String lower = keyword.toLowerCase();
        ObservableList<PasswordEntry> result = FXCollections.observableArrayList();

        for (PasswordEntry entry : repository.findAll()) {
            if (safe(entry.getServiceName()).contains(lower)
                    || safe(entry.getUsername()).contains(lower)
                    || safe(entry.getNote()).contains(lower)) {
                result.add(entry);
            }
        }

        return result;
    }

    private String safe(String value) {
        return value == null ? "" : value.toLowerCase();
    }
}