package main.application_oop.controller;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.util.Duration;
import main.application_oop.model.PasswordEntry;
import main.application_oop.service.PasswordService;

import java.util.Optional;

public class PasswordController {

    @FXML private ComboBox<String> serviceComboBox;
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private TextField noteField;
    @FXML private TextField searchField;

    @FXML private TableView<PasswordEntry> passwordTable;
    @FXML private TableColumn<PasswordEntry, String> serviceColumn;
    @FXML private TableColumn<PasswordEntry, String> usernameColumn;
    @FXML private TableColumn<PasswordEntry, String> passwordColumn;
    @FXML private TableColumn<PasswordEntry, String> noteColumn;

    @FXML private Button addButton;
    @FXML private Button updateButton;
    @FXML private Button deleteButton;

    private final PasswordService service = new PasswordService();

    private final ObservableList<String> serviceOptions = FXCollections.observableArrayList(
            "Gmail", "Facebook", "Zalo", "Instagram", "TikTok"
    );

    private PasswordEntry selectedForEdit = null;
    private boolean editMode = false;

    @FXML
    public void initialize() {
        serviceColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("serviceName"));
        usernameColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("username"));
        passwordColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("password"));
        noteColumn.setCellValueFactory(new javafx.scene.control.cell.PropertyValueFactory<>("note"));

        serviceComboBox.setItems(serviceOptions);
        serviceComboBox.getSelectionModel().selectFirst();

        passwordTable.setItems(service.getAll());
        passwordTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            selectedForEdit = newVal;
            playPulse(passwordTable);
        });

        playFadeIn(passwordTable);
    }

    @FXML
    private void handleCreateService() {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Tạo dịch vụ");
        dialog.setHeaderText(null);
        dialog.setContentText("Nhập tên dịch vụ mới:");

        Optional<String> result = dialog.showAndWait();
        result.map(String::trim)
                .filter(name -> !name.isBlank())
                .ifPresent(name -> {
                    if (!serviceOptions.contains(name)) {
                        serviceOptions.add(name);
                    }
                    serviceComboBox.getSelectionModel().select(name);
                    playPulse(serviceComboBox);
                });
    }

    @FXML
    private void handleAdd() {
        if (isInvalidInput()) return;

        service.addPassword(
                serviceComboBox.getValue(),
                usernameField.getText(),
                passwordField.getText(),
                noteField.getText()
        );

        clearFields();
        resetEditState();
        passwordTable.setItems(service.getAll());
        playPulse(addButton);
    }

    @FXML
    private void handleUpdate() {
        if (!editMode) {
            PasswordEntry selected = passwordTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert("Vui lòng chọn một dòng để sửa.");
                return;
            }

            selectedForEdit = selected;
            serviceComboBox.getSelectionModel().select(selected.getServiceName());
            usernameField.setText(selected.getUsername());
            passwordField.setText(selected.getPassword());
            noteField.setText(selected.getNote());

            editMode = true;
            playPulse(updateButton);
            return;
        }

        if (selectedForEdit == null) {
            showAlert("Không có dữ liệu để sửa.");
            editMode = false;
            return;
        }

        if (isInvalidInput()) return;

        service.updatePassword(
                selectedForEdit,
                serviceComboBox.getValue(),
                usernameField.getText(),
                passwordField.getText(),
                noteField.getText()
        );

        passwordTable.refresh();
        clearFields();
        resetEditState();
        playPulse(updateButton);
    }

    @FXML
    private void handleDelete() {
        PasswordEntry selected = passwordTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Vui lòng chọn một dòng để xoá.");
            return;
        }

        service.deletePassword(selected);
        clearFields();
        resetEditState();
        passwordTable.setItems(service.getAll());
        playPulse(deleteButton);
    }

    @FXML
    private void handleSearch() {
        passwordTable.setItems(service.search(searchField.getText()));
        resetEditState();
        playPulse(searchField);
    }

    @FXML
    private void handleShowAll() {
        passwordTable.setItems(service.getAll());
        resetEditState();
    }

    private boolean isInvalidInput() {
        if (serviceComboBox.getValue() == null
                || serviceComboBox.getValue().isBlank()
                || usernameField.getText().isBlank()
                || passwordField.getText().isBlank()) {
            showAlert("Vui lòng nhập đủ thông tin.");
            return true;
        }
        return false;
    }

    private void clearFields() {
        serviceComboBox.getSelectionModel().clearSelection();
        usernameField.clear();
        passwordField.clear();
        noteField.clear();
    }

    private void resetEditState() {
        selectedForEdit = null;
        editMode = false;
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Thông báo");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void playFadeIn(Node node) {
        FadeTransition ft = new FadeTransition(Duration.millis(450), node);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();
    }

    private void playPulse(Node node) {
        ScaleTransition st = new ScaleTransition(Duration.millis(140), node);
        st.setFromX(1.0);
        st.setFromY(1.0);
        st.setToX(1.03);
        st.setToY(1.03);
        st.setAutoReverse(true);
        st.setCycleCount(2);
        st.play();
    }
}