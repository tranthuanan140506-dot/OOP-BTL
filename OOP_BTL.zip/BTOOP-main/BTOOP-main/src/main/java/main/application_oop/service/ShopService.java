package main.application_oop.service;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import main.application_oop.model.BreedInfo;
import main.application_oop.model.Product;
import main.application_oop.model.ServiceRegistration;
import main.application_oop.model.SpaPackage;
import main.application_oop.model.StaffMember;

import java.util.ArrayList;
import java.util.List;

public class ShopService {
    private final ObservableList<Product> products = FXCollections.observableArrayList(
            new Product("SP01", "Hat dinh duong cho cho", "Thuc an", "Cho", 120000, 28),
            new Product("SP02", "Pate vi ca cho meo", "Thuc an", "Meo", 35000, 54),
            new Product("SP03", "Day dat cho cho", "Phu kien", "Cho", 180000, 12),
            new Product("SP04", "Cat ve sinh cho meo", "Ve sinh", "Meo", 95000, 33),
            new Product("SP05", "Bong gau do choi", "Do choi", "Cho", 65000, 20),
            new Product("SP06", "Can cau long vu", "Do choi", "Meo", 45000, 26)
    );

    private final ObservableList<BreedInfo> catBreeds = FXCollections.observableArrayList(
            new BreedInfo("Anh Long Ngan", "Meo", "Anh", "Hien, de cham, than thien", 8000000, 4),
            new BreedInfo("Ba Tu", "Meo", "Iran", "Diu dang, thich o trong nha", 12000000, 3),
            new BreedInfo("Maine Coon", "Meo", "My", "Thong minh, to lon, hoa dong", 18000000, 2)
    );

    private final ObservableList<BreedInfo> dogBreeds = FXCollections.observableArrayList(
            new BreedInfo("Poodle", "Cho", "Phap", "Thong minh, nang dong, de huan luyen", 7000000, 5),
            new BreedInfo("Corgi", "Cho", "Anh", "Than thien, vui ve, chan ngan", 14000000, 3),
            new BreedInfo("Golden Retriever", "Cho", "Scotland", "Hien lanh, gan gui, hop gia dinh", 16000000, 2)
    );

    private final ObservableList<SpaPackage> spaPackages = FXCollections.observableArrayList(
            new SpaPackage("Tam va say co ban", "Cho", "Lam sach long, say kho va ve sinh tai", 45, 180000),
            new SpaPackage("Cat tia tao kieu", "Cho", "Cat long theo form, tia gon chan va duoi", 75, 320000),
            new SpaPackage("Tam duong long meo", "Meo", "Tam kho, goi duong va go roi long", 50, 220000),
            new SpaPackage("Spa tron goi cho meo", "Meo", "Tam, cat mong, ve sinh tai va cham long", 80, 360000)
    );

    private final ObservableList<StaffMember> staffMembers = FXCollections.observableArrayList(
            new StaffMember("NV01", "Tran Minh Chau", "Quan ly cua hang", "Ca sang", "0901234567"),
            new StaffMember("NV02", "Le Bao Han", "Nhan vien ban hang", "Ca chieu", "0912345678"),
            new StaffMember("NV03", "Nguyen Tuan Kiet", "Ky thuat vien spa", "Ca sang", "0923456789"),
            new StaffMember("NV04", "Pham Ngoc Mai", "Thu ngan", "Ca toi", "0934567890")
    );

    private final ObservableList<ServiceRegistration> serviceRegistrations = FXCollections.observableArrayList(
            new ServiceRegistration("Doan Gia Linh", "0988111222", "Miu", "Meo", "Spa tron goi cho meo, Pate vi ca cho meo", "09:00 08/04", 395000),
            new ServiceRegistration("Hoang Anh Tuan", "0977222333", "Bim", "Cho", "Day dat cho cho, Tam va say co ban", "14:30 08/04", 360000)
    );

    public ObservableList<Product> getProducts() {
        return products;
    }

    public ObservableList<BreedInfo> getCatBreeds() {
        return catBreeds;
    }

    public ObservableList<BreedInfo> getDogBreeds() {
        return dogBreeds;
    }

    public ObservableList<SpaPackage> getSpaPackages() {
        return spaPackages;
    }

    public ObservableList<StaffMember> getStaffMembers() {
        return staffMembers;
    }

    public ObservableList<ServiceRegistration> getServiceRegistrations() {
        return serviceRegistrations;
    }

    public ObservableList<Product> searchProducts(String keyword) {
        if (keyword == null || keyword.isBlank()) {
            return products;
        }
        String lower = keyword.toLowerCase();
        return products.filtered(product ->
                product.getId().toLowerCase().contains(lower)
                        || product.getName().toLowerCase().contains(lower)
                        || product.getCategory().toLowerCase().contains(lower)
                        || product.getPetType().toLowerCase().contains(lower));
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public void deleteProduct(Product product) {
        products.remove(product);
    }

    public void addCatBreed(BreedInfo breedInfo) {
        catBreeds.add(breedInfo);
    }

    public void deleteCatBreed(BreedInfo breedInfo) {
        catBreeds.remove(breedInfo);
    }

    public void addDogBreed(BreedInfo breedInfo) {
        dogBreeds.add(breedInfo);
    }

    public void deleteDogBreed(BreedInfo breedInfo) {
        dogBreeds.remove(breedInfo);
    }

    public void addSpaPackage(SpaPackage spaPackage) {
        spaPackages.add(spaPackage);
    }

    public void deleteSpaPackage(SpaPackage spaPackage) {
        spaPackages.remove(spaPackage);
    }

    public void addStaffMember(StaffMember staffMember) {
        staffMembers.add(staffMember);
    }

    public void deleteStaffMember(StaffMember staffMember) {
        staffMembers.remove(staffMember);
    }

    public void addServiceRegistration(ServiceRegistration registration) {
        serviceRegistrations.add(registration);
    }

    public void deleteServiceRegistration(ServiceRegistration registration) {
        serviceRegistrations.remove(registration);
    }

    public ObservableList<Product> getProductsByPetType(String petType) {
        if (petType == null || petType.isBlank()) {
            return products;
        }
        return products.filtered(product -> product.getPetType().equalsIgnoreCase(petType));
    }

    public ObservableList<SpaPackage> getSpaPackagesByPetType(String petType) {
        if (petType == null || petType.isBlank()) {
            return spaPackages;
        }
        return spaPackages.filtered(spaPackage -> spaPackage.getPetType().equalsIgnoreCase(petType));
    }

    public List<String> getAllOfferingTypes() {
        return List.of("San pham", "Giong meo", "Giong cho", "Spa");
    }

    public List<String> getOfferingNamesByType(String offeringType) {
        return switch (offeringType) {
            case "San pham" -> products.stream().map(Product::getName).toList();
            case "Giong meo" -> catBreeds.stream().map(BreedInfo::getName).toList();
            case "Giong cho" -> dogBreeds.stream().map(BreedInfo::getName).toList();
            case "Spa" -> spaPackages.stream().map(SpaPackage::getName).toList();
            default -> new ArrayList<>();
        };
    }

    public double getOfferingPrice(String offeringType, String offeringName) {
        return switch (offeringType) {
            case "San pham" -> products.stream().filter(item -> item.getName().equals(offeringName)).findFirst().map(Product::getPrice).orElse(0.0);
            case "Giong meo" -> catBreeds.stream().filter(item -> item.getName().equals(offeringName)).findFirst().map(BreedInfo::getAveragePrice).orElse(0.0);
            case "Giong cho" -> dogBreeds.stream().filter(item -> item.getName().equals(offeringName)).findFirst().map(BreedInfo::getAveragePrice).orElse(0.0);
            case "Spa" -> spaPackages.stream().filter(item -> item.getName().equals(offeringName)).findFirst().map(SpaPackage::getPrice).orElse(0.0);
            default -> 0.0;
        };
    }

    public int getTotalStock() {
        return products.stream().mapToInt(Product::getStock).sum();
    }

    public double getTotalShopValue() {
        double productValue = products.stream().mapToDouble(Product::getTotalValue).sum();
        double catBreedValue = catBreeds.stream().mapToDouble(item -> item.getAveragePrice() * item.getQuantity()).sum();
        double dogBreedValue = dogBreeds.stream().mapToDouble(item -> item.getAveragePrice() * item.getQuantity()).sum();
        return productValue + catBreedValue + dogBreedValue;
    }
}
