package main.application_oop.controller;

import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.application_oop.HelloApplication;
import main.application_oop.model.BreedInfo;
import main.application_oop.model.Product;
import main.application_oop.model.RegistrationItem;
import main.application_oop.model.ServiceRegistration;
import main.application_oop.model.SpaPackage;
import main.application_oop.model.StaffMember;
import main.application_oop.service.ShopService;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.stream.Collectors;

public class ShopController {
    @FXML private Label productCountLabel;
    @FXML private Label totalStockLabel;
    @FXML private Label breedCountLabel;
    @FXML private Label totalShopValueLabel;
    @FXML private Label registrationStatusLabel;
    @FXML private Label currentRegistrationTotalLabel;

    @FXML private TableView<Product> productTable;
    @FXML private TableColumn<Product, String> productIdColumn;
    @FXML private TableColumn<Product, String> productNameColumn;
    @FXML private TableColumn<Product, String> productCategoryColumn;
    @FXML private TableColumn<Product, String> productPetTypeColumn;
    @FXML private TableColumn<Product, Double> productPriceColumn;
    @FXML private TableColumn<Product, Integer> productStockColumn;
    @FXML private TableColumn<Product, Double> productTotalValueColumn;
    @FXML private TextField productIdField;
    @FXML private TextField productNameField;
    @FXML private TextField productCategoryField;
    @FXML private ComboBox<String> productPetTypeField;
    @FXML private TextField productPriceField;
    @FXML private TextField productStockField;
    @FXML private TextField productSearchField;

    @FXML private TableView<StaffMember> staffTable;
    @FXML private TableColumn<StaffMember, String> staffIdColumn;
    @FXML private TableColumn<StaffMember, String> staffNameColumn;
    @FXML private TableColumn<StaffMember, String> staffRoleColumn;
    @FXML private TableColumn<StaffMember, String> staffShiftColumn;
    @FXML private TableColumn<StaffMember, String> staffPhoneColumn;
    @FXML private TextField staffIdField;
    @FXML private TextField staffNameField;
    @FXML private TextField staffRoleField;
    @FXML private TextField staffShiftField;
    @FXML private TextField staffPhoneField;

    @FXML private TableView<BreedInfo> catBreedTable;
    @FXML private TableColumn<BreedInfo, String> catBreedNameColumn;
    @FXML private TableColumn<BreedInfo, String> catOriginColumn;
    @FXML private TableColumn<BreedInfo, String> catPersonalityColumn;
    @FXML private TableColumn<BreedInfo, Double> catPriceColumn;
    @FXML private TableColumn<BreedInfo, Integer> catQuantityColumn;
    @FXML private TableColumn<BreedInfo, Double> catTotalValueColumn;
    @FXML private TextField catBreedNameField;
    @FXML private TextField catOriginField;
    @FXML private TextField catPersonalityField;
    @FXML private TextField catPriceField;
    @FXML private TextField catQuantityField;

    @FXML private TableView<BreedInfo> dogBreedTable;
    @FXML private TableColumn<BreedInfo, String> dogBreedNameColumn;
    @FXML private TableColumn<BreedInfo, String> dogOriginColumn;
    @FXML private TableColumn<BreedInfo, String> dogPersonalityColumn;
    @FXML private TableColumn<BreedInfo, Double> dogPriceColumn;
    @FXML private TableColumn<BreedInfo, Integer> dogQuantityColumn;
    @FXML private TableColumn<BreedInfo, Double> dogTotalValueColumn;
    @FXML private TextField dogBreedNameField;
    @FXML private TextField dogOriginField;
    @FXML private TextField dogPersonalityField;
    @FXML private TextField dogPriceField;
    @FXML private TextField dogQuantityField;

    @FXML private TableView<SpaPackage> spaTable;
    @FXML private TableColumn<SpaPackage, String> spaNameColumn;
    @FXML private TableColumn<SpaPackage, String> spaPetTypeColumn;
    @FXML private TableColumn<SpaPackage, String> spaDescriptionColumn;
    @FXML private TableColumn<SpaPackage, Integer> spaDurationColumn;
    @FXML private TableColumn<SpaPackage, Double> spaPriceColumn;
    @FXML private TextField spaNameField;
    @FXML private ComboBox<String> spaPetTypeField;
    @FXML private TextField spaDescriptionField;
    @FXML private TextField spaDurationField;
    @FXML private TextField spaPriceField;

    @FXML private TableView<ServiceRegistration> registrationTable;
    @FXML private TableColumn<ServiceRegistration, String> customerNameColumn;
    @FXML private TableColumn<ServiceRegistration, String> customerPhoneColumn;
    @FXML private TableColumn<ServiceRegistration, String> petNameColumn;
    @FXML private TableColumn<ServiceRegistration, String> registrationPetTypeColumn;
    @FXML private TableColumn<ServiceRegistration, String> itemSummaryColumn;
    @FXML private TableColumn<ServiceRegistration, String> appointmentTimeColumn;
    @FXML private TableColumn<ServiceRegistration, Double> registrationTotalColumn;
    @FXML private TextField customerNameField;
    @FXML private TextField customerPhoneField;
    @FXML private TextField petNameField;
    @FXML private ComboBox<String> registrationPetTypeField;
    @FXML private ComboBox<String> offeringTypeField;
    @FXML private ComboBox<String> offeringNameField;
    @FXML private TextField appointmentTimeField;
    @FXML private TableView<RegistrationItem> currentItemsTable;
    @FXML private TableColumn<RegistrationItem, String> currentItemTypeColumn;
    @FXML private TableColumn<RegistrationItem, String> currentItemNameColumn;
    @FXML private TableColumn<RegistrationItem, Double> currentItemPriceColumn;

    private final ShopService shopService = new ShopService();
    private final ObservableList<RegistrationItem> currentRegistrationItems = FXCollections.observableArrayList();
    private final NumberFormat vndFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

    @FXML
    public void initialize() {
        setupTables();
        setupForms();
        bindTables();
        bindSelections();
        updateOfferingNames();
        updateCurrentRegistrationTotal();
        updateSummary();
        registrationStatusLabel.setText("");
        playFadeIn(productTable);
    }

    @FXML
    private void showAllProducts() {
        productTable.setItems(shopService.getProducts());
        productCountLabel.setText(String.valueOf(productTable.getItems().size()));
        playPulse(productTable);
    }

    @FXML
    private void filterDogProducts() {
        productTable.setItems(shopService.getProductsByPetType("Cho"));
        productCountLabel.setText(String.valueOf(productTable.getItems().size()));
    }

    @FXML
    private void filterCatProducts() {
        productTable.setItems(shopService.getProductsByPetType("Meo"));
        productCountLabel.setText(String.valueOf(productTable.getItems().size()));
    }

    @FXML
    private void handleSearchProducts() {
        productTable.setItems(shopService.searchProducts(productSearchField.getText()));
        productCountLabel.setText(String.valueOf(productTable.getItems().size()));
    }

    @FXML
    private void showAllSpaPackages() {
        spaTable.setItems(shopService.getSpaPackages());
    }

    @FXML
    private void filterDogSpaPackages() {
        spaTable.setItems(shopService.getSpaPackagesByPetType("Cho"));
    }

    @FXML
    private void filterCatSpaPackages() {
        spaTable.setItems(shopService.getSpaPackagesByPetType("Meo"));
    }

    @FXML
    private void handleAddProduct() {
        shopService.addProduct(new Product(productIdField.getText().trim(), productNameField.getText().trim(), productCategoryField.getText().trim(), productPetTypeField.getValue(), parseDouble(productPriceField), parseInt(productStockField)));
        clearProductForm();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleUpdateProduct() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        selected.setId(productIdField.getText().trim());
        selected.setName(productNameField.getText().trim());
        selected.setCategory(productCategoryField.getText().trim());
        selected.setPetType(productPetTypeField.getValue());
        selected.setPrice(parseDouble(productPriceField));
        selected.setStock(parseInt(productStockField));
        productTable.refresh();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleDeleteProduct() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        shopService.deleteProduct(selected);
        clearProductForm();
        showAllProducts();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleAddStaff() {
        shopService.addStaffMember(new StaffMember(staffIdField.getText().trim(), staffNameField.getText().trim(), staffRoleField.getText().trim(), staffShiftField.getText().trim(), staffPhoneField.getText().trim()));
        clearStaffForm();
    }

    @FXML
    private void handleUpdateStaff() {
        StaffMember selected = staffTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        selected.setId(staffIdField.getText().trim());
        selected.setName(staffNameField.getText().trim());
        selected.setRole(staffRoleField.getText().trim());
        selected.setShift(staffShiftField.getText().trim());
        selected.setPhone(staffPhoneField.getText().trim());
        staffTable.refresh();
    }

    @FXML
    private void handleDeleteStaff() {
        StaffMember selected = staffTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        shopService.deleteStaffMember(selected);
        clearStaffForm();
    }

    @FXML
    private void handleAddCatBreed() {
        shopService.addCatBreed(new BreedInfo(catBreedNameField.getText().trim(), "Meo", catOriginField.getText().trim(), catPersonalityField.getText().trim(), parseDouble(catPriceField), parseInt(catQuantityField)));
        clearCatForm();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleUpdateCatBreed() {
        BreedInfo selected = catBreedTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        selected.setName(catBreedNameField.getText().trim());
        selected.setOrigin(catOriginField.getText().trim());
        selected.setPersonality(catPersonalityField.getText().trim());
        selected.setAveragePrice(parseDouble(catPriceField));
        selected.setQuantity(parseInt(catQuantityField));
        catBreedTable.refresh();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleDeleteCatBreed() {
        BreedInfo selected = catBreedTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        shopService.deleteCatBreed(selected);
        clearCatForm();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleAddDogBreed() {
        shopService.addDogBreed(new BreedInfo(dogBreedNameField.getText().trim(), "Cho", dogOriginField.getText().trim(), dogPersonalityField.getText().trim(), parseDouble(dogPriceField), parseInt(dogQuantityField)));
        clearDogForm();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleUpdateDogBreed() {
        BreedInfo selected = dogBreedTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        selected.setName(dogBreedNameField.getText().trim());
        selected.setOrigin(dogOriginField.getText().trim());
        selected.setPersonality(dogPersonalityField.getText().trim());
        selected.setAveragePrice(parseDouble(dogPriceField));
        selected.setQuantity(parseInt(dogQuantityField));
        dogBreedTable.refresh();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleDeleteDogBreed() {
        BreedInfo selected = dogBreedTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        shopService.deleteDogBreed(selected);
        clearDogForm();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleAddSpa() {
        shopService.addSpaPackage(new SpaPackage(spaNameField.getText().trim(), spaPetTypeField.getValue(), spaDescriptionField.getText().trim(), parseInt(spaDurationField), parseDouble(spaPriceField)));
        clearSpaForm();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleUpdateSpa() {
        SpaPackage selected = spaTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        selected.setName(spaNameField.getText().trim());
        selected.setPetType(spaPetTypeField.getValue());
        selected.setDescription(spaDescriptionField.getText().trim());
        selected.setDurationMinutes(parseInt(spaDurationField));
        selected.setPrice(parseDouble(spaPriceField));
        spaTable.refresh();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleDeleteSpa() {
        SpaPackage selected = spaTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        shopService.deleteSpaPackage(selected);
        clearSpaForm();
        refreshOfferingsAndSummary();
    }

    @FXML
    private void handleOfferingTypeChange() {
        updateOfferingNames();
    }

    @FXML
    private void handleAddRegistrationItem() {
        String type = offeringTypeField.getValue();
        String name = offeringNameField.getValue();
        if (type == null || name == null) return;
        currentRegistrationItems.add(new RegistrationItem(type, name, shopService.getOfferingPrice(type, name)));
        updateCurrentRegistrationTotal();
        registrationStatusLabel.setText("Da them hang muc vao don.");
    }

    @FXML
    private void handleRemoveRegistrationItem() {
        RegistrationItem selected = currentItemsTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        currentRegistrationItems.remove(selected);
        updateCurrentRegistrationTotal();
    }

    @FXML
    private void handleAddRegistration() {
        if (currentRegistrationItems.isEmpty()) {
            registrationStatusLabel.setText("Can them it nhat mot hang muc.");
            return;
        }
        shopService.addServiceRegistration(new ServiceRegistration(
                customerNameField.getText().trim(),
                customerPhoneField.getText().trim(),
                petNameField.getText().trim(),
                registrationPetTypeField.getValue(),
                currentRegistrationItems.stream().map(RegistrationItem::getOfferingName).collect(Collectors.joining(", ")),
                appointmentTimeField.getText().trim(),
                currentRegistrationItems.stream().mapToDouble(RegistrationItem::getPrice).sum()
        ));
        clearRegistrationForm();
        registrationStatusLabel.setText("Da tao dang ky khach hang.");
    }

    @FXML
    private void handleUpdateRegistration() {
        ServiceRegistration selected = registrationTable.getSelectionModel().getSelectedItem();
        if (selected == null || currentRegistrationItems.isEmpty()) return;
        selected.setCustomerName(customerNameField.getText().trim());
        selected.setPhone(customerPhoneField.getText().trim());
        selected.setPetName(petNameField.getText().trim());
        selected.setPetType(registrationPetTypeField.getValue());
        selected.setItemSummary(currentRegistrationItems.stream().map(RegistrationItem::getOfferingName).collect(Collectors.joining(", ")));
        selected.setAppointmentTime(appointmentTimeField.getText().trim());
        selected.setTotalAmount(currentRegistrationItems.stream().mapToDouble(RegistrationItem::getPrice).sum());
        registrationTable.refresh();
        registrationStatusLabel.setText("Da cap nhat dang ky.");
    }

    @FXML
    private void handleDeleteRegistration() {
        ServiceRegistration selected = registrationTable.getSelectionModel().getSelectedItem();
        if (selected == null) return;
        shopService.deleteServiceRegistration(selected);
        clearRegistrationForm();
        registrationStatusLabel.setText("Da xoa dang ky.");
    }

    @FXML
    private void handleLogout() throws Exception {
        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/login-view.fxml"));
        Scene scene = new Scene(loader.load(), 520, 420);
        scene.getStylesheets().add(HelloApplication.class.getResource("/view/app.css").toExternalForm());
        Stage stage = (Stage) productTable.getScene().getWindow();
        stage.setTitle("Dang nhap");
        stage.setScene(scene);
        stage.show();
    }

    private void setupTables() {
        productIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        productCategoryColumn.setCellValueFactory(new PropertyValueFactory<>("category"));
        productPetTypeColumn.setCellValueFactory(new PropertyValueFactory<>("petType"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        productStockColumn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productTotalValueColumn.setCellValueFactory(new PropertyValueFactory<>("totalValue"));

        staffIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        staffNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        staffRoleColumn.setCellValueFactory(new PropertyValueFactory<>("role"));
        staffShiftColumn.setCellValueFactory(new PropertyValueFactory<>("shift"));
        staffPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));

        catBreedNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        catOriginColumn.setCellValueFactory(new PropertyValueFactory<>("origin"));
        catPersonalityColumn.setCellValueFactory(new PropertyValueFactory<>("personality"));
        catPriceColumn.setCellValueFactory(new PropertyValueFactory<>("averagePrice"));
        catQuantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        catTotalValueColumn.setCellValueFactory(new PropertyValueFactory<>("totalValue"));

        dogBreedNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        dogOriginColumn.setCellValueFactory(new PropertyValueFactory<>("origin"));
        dogPersonalityColumn.setCellValueFactory(new PropertyValueFactory<>("personality"));
        dogPriceColumn.setCellValueFactory(new PropertyValueFactory<>("averagePrice"));
        dogQuantityColumn.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        dogTotalValueColumn.setCellValueFactory(new PropertyValueFactory<>("totalValue"));

        spaNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        spaPetTypeColumn.setCellValueFactory(new PropertyValueFactory<>("petType"));
        spaDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        spaDurationColumn.setCellValueFactory(new PropertyValueFactory<>("durationMinutes"));
        spaPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        customerNameColumn.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        customerPhoneColumn.setCellValueFactory(new PropertyValueFactory<>("phone"));
        petNameColumn.setCellValueFactory(new PropertyValueFactory<>("petName"));
        registrationPetTypeColumn.setCellValueFactory(new PropertyValueFactory<>("petType"));
        itemSummaryColumn.setCellValueFactory(new PropertyValueFactory<>("itemSummary"));
        appointmentTimeColumn.setCellValueFactory(new PropertyValueFactory<>("appointmentTime"));
        registrationTotalColumn.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));

        currentItemTypeColumn.setCellValueFactory(new PropertyValueFactory<>("offeringType"));
        currentItemNameColumn.setCellValueFactory(new PropertyValueFactory<>("offeringName"));
        currentItemPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        applyVndFormat(productPriceColumn);
        applyVndFormat(productTotalValueColumn);
        applyVndFormat(catPriceColumn);
        applyVndFormat(catTotalValueColumn);
        applyVndFormat(dogPriceColumn);
        applyVndFormat(dogTotalValueColumn);
        applyVndFormat(spaPriceColumn);
        applyVndFormat(registrationTotalColumn);
        applyVndFormat(currentItemPriceColumn);
    }

    private void setupForms() {
        productPetTypeField.setItems(FXCollections.observableArrayList("Cho", "Meo"));
        productPetTypeField.getSelectionModel().selectFirst();
        spaPetTypeField.setItems(FXCollections.observableArrayList("Cho", "Meo"));
        spaPetTypeField.getSelectionModel().selectFirst();
        registrationPetTypeField.setItems(FXCollections.observableArrayList("Cho", "Meo"));
        registrationPetTypeField.getSelectionModel().selectFirst();
        offeringTypeField.setItems(FXCollections.observableArrayList(shopService.getAllOfferingTypes()));
        offeringTypeField.getSelectionModel().selectFirst();
        offeringTypeField.valueProperty().addListener((obs, oldVal, newVal) -> updateOfferingNames());
    }

    private void bindTables() {
        productTable.setItems(shopService.getProducts());
        staffTable.setItems(shopService.getStaffMembers());
        catBreedTable.setItems(shopService.getCatBreeds());
        dogBreedTable.setItems(shopService.getDogBreeds());
        spaTable.setItems(shopService.getSpaPackages());
        registrationTable.setItems(shopService.getServiceRegistrations());
        currentItemsTable.setItems(currentRegistrationItems);
        productCountLabel.setText(String.valueOf(shopService.getProducts().size()));
    }

    private void bindSelections() {
        productTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, item) -> {
            if (item != null) {
                productIdField.setText(item.getId());
                productNameField.setText(item.getName());
                productCategoryField.setText(item.getCategory());
                productPetTypeField.setValue(item.getPetType());
                productPriceField.setText(String.valueOf(item.getPrice()));
                productStockField.setText(String.valueOf(item.getStock()));
            }
        });
        staffTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, item) -> {
            if (item != null) {
                staffIdField.setText(item.getId());
                staffNameField.setText(item.getName());
                staffRoleField.setText(item.getRole());
                staffShiftField.setText(item.getShift());
                staffPhoneField.setText(item.getPhone());
            }
        });
        catBreedTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, item) -> {
            if (item != null) {
                catBreedNameField.setText(item.getName());
                catOriginField.setText(item.getOrigin());
                catPersonalityField.setText(item.getPersonality());
                catPriceField.setText(String.valueOf(item.getAveragePrice()));
                catQuantityField.setText(String.valueOf(item.getQuantity()));
            }
        });
        dogBreedTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, item) -> {
            if (item != null) {
                dogBreedNameField.setText(item.getName());
                dogOriginField.setText(item.getOrigin());
                dogPersonalityField.setText(item.getPersonality());
                dogPriceField.setText(String.valueOf(item.getAveragePrice()));
                dogQuantityField.setText(String.valueOf(item.getQuantity()));
            }
        });
        spaTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, item) -> {
            if (item != null) {
                spaNameField.setText(item.getName());
                spaPetTypeField.setValue(item.getPetType());
                spaDescriptionField.setText(item.getDescription());
                spaDurationField.setText(String.valueOf(item.getDurationMinutes()));
                spaPriceField.setText(String.valueOf(item.getPrice()));
            }
        });
        registrationTable.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, item) -> {
            if (item != null) {
                customerNameField.setText(item.getCustomerName());
                customerPhoneField.setText(item.getPhone());
                petNameField.setText(item.getPetName());
                registrationPetTypeField.setValue(item.getPetType());
                appointmentTimeField.setText(item.getAppointmentTime());
                currentRegistrationItems.clear();
                for (String name : item.getItemSummary().split(", ")) {
                    String inferredType = inferOfferingType(name);
                    currentRegistrationItems.add(new RegistrationItem(inferredType, name, shopService.getOfferingPrice(inferredType, name)));
                }
                updateCurrentRegistrationTotal();
            }
        });
    }

    private String inferOfferingType(String name) {
        for (String type : shopService.getAllOfferingTypes()) {
            if (shopService.getOfferingNamesByType(type).contains(name)) {
                return type;
            }
        }
        return "San pham";
    }

    private void updateOfferingNames() {
        offeringNameField.setItems(FXCollections.observableArrayList(shopService.getOfferingNamesByType(offeringTypeField.getValue())));
        if (!offeringNameField.getItems().isEmpty()) {
            offeringNameField.getSelectionModel().selectFirst();
        }
    }

    private <T> void applyVndFormat(TableColumn<T, Double> column) {
        column.setCellFactory(col -> new TableCell<T, Double>() {
            @Override
            protected void updateItem(Double item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : vndFormat.format(item));
            }
        });
    }

    private void refreshOfferingsAndSummary() {
        productTable.refresh();
        catBreedTable.refresh();
        dogBreedTable.refresh();
        spaTable.refresh();
        updateOfferingNames();
        updateSummary();
        productCountLabel.setText(String.valueOf(shopService.getProducts().size()));
    }

    private void updateCurrentRegistrationTotal() {
        double total = currentRegistrationItems.stream().mapToDouble(RegistrationItem::getPrice).sum();
        currentRegistrationTotalLabel.setText(vndFormat.format(total));
        currentItemsTable.refresh();
    }

    private void updateSummary() {
        totalStockLabel.setText(String.valueOf(shopService.getTotalStock()));
        int breedCount = shopService.getCatBreeds().size() + shopService.getDogBreeds().size();
        breedCountLabel.setText(String.valueOf(breedCount));
        totalShopValueLabel.setText(vndFormat.format(shopService.getTotalShopValue()));
    }

    private double parseDouble(TextField field) {
        String value = field.getText() == null ? "" : field.getText().trim();
        return value.isEmpty() ? 0 : Double.parseDouble(value);
    }

    private int parseInt(TextField field) {
        String value = field.getText() == null ? "" : field.getText().trim();
        return value.isEmpty() ? 0 : Integer.parseInt(value);
    }

    private void clearProductForm() {
        productIdField.clear();
        productNameField.clear();
        productCategoryField.clear();
        productPriceField.clear();
        productStockField.clear();
        productSearchField.clear();
        productPetTypeField.getSelectionModel().selectFirst();
    }

    private void clearStaffForm() {
        staffIdField.clear();
        staffNameField.clear();
        staffRoleField.clear();
        staffShiftField.clear();
        staffPhoneField.clear();
    }

    private void clearCatForm() {
        catBreedNameField.clear();
        catOriginField.clear();
        catPersonalityField.clear();
        catPriceField.clear();
        catQuantityField.clear();
    }

    private void clearDogForm() {
        dogBreedNameField.clear();
        dogOriginField.clear();
        dogPersonalityField.clear();
        dogPriceField.clear();
        dogQuantityField.clear();
    }

    private void clearSpaForm() {
        spaNameField.clear();
        spaDescriptionField.clear();
        spaDurationField.clear();
        spaPriceField.clear();
        spaPetTypeField.getSelectionModel().selectFirst();
    }

    private void clearRegistrationForm() {
        customerNameField.clear();
        customerPhoneField.clear();
        petNameField.clear();
        appointmentTimeField.clear();
        registrationPetTypeField.getSelectionModel().selectFirst();
        offeringTypeField.getSelectionModel().selectFirst();
        currentRegistrationItems.clear();
        updateOfferingNames();
        updateCurrentRegistrationTotal();
    }

    private void playFadeIn(Node node) {
        FadeTransition ft = new FadeTransition(Duration.millis(500), node);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();
    }

    private void playPulse(Node node) {
        ScaleTransition st = new ScaleTransition(Duration.millis(140), node);
        st.setFromX(1.0);
        st.setFromY(1.0);
        st.setToX(1.01);
        st.setToY(1.01);
        st.setAutoReverse(true);
        st.setCycleCount(2);
        st.play();
    }
}
