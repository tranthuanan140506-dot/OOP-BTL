package main.application_oop.model;

public class ServiceRegistration {
    private String customerName;
    private String phone;
    private String petName;
    private String petType;
    private String itemSummary;
    private String appointmentTime;
    private double totalAmount;

    public ServiceRegistration(String customerName, String phone, String petName, String petType, String itemSummary, String appointmentTime, double totalAmount) {
        this.customerName = customerName;
        this.phone = phone;
        this.petName = petName;
        this.petType = petType;
        this.itemSummary = itemSummary;
        this.appointmentTime = appointmentTime;
        this.totalAmount = totalAmount;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetType() {
        return petType;
    }

    public void setPetType(String petType) {
        this.petType = petType;
    }

    public String getItemSummary() {
        return itemSummary;
    }

    public void setItemSummary(String itemSummary) {
        this.itemSummary = itemSummary;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }
}
