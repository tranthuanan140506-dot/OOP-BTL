package main.application_oop.controller;

import javafx.animation.FadeTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.util.Duration;
import main.application_oop.HelloApplication;
import main.application_oop.service.AuthService;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;
    @FXML private Label statusLabel;

    private final AuthService authService = new AuthService();

    @FXML
    public void initialize() {
        FadeTransition fadeTransition = new FadeTransition(Duration.millis(500), statusLabel);
        fadeTransition.setFromValue(0.2);
        fadeTransition.setToValue(1.0);
        fadeTransition.play();
        statusLabel.setText("");
    }

    @FXML
    private void handleLogin() throws Exception {
        String username = usernameField.getText() == null ? "" : usernameField.getText().trim();
        String password = passwordField.getText() == null ? "" : passwordField.getText().trim();

        if (!authService.authenticate(username, password)) {
            statusLabel.setText("Sai ten dang nhap hoac mat khau.");
            return;
        }

        FXMLLoader loader = new FXMLLoader(HelloApplication.class.getResource("/view/shop-view.fxml"));
        Scene scene = new Scene(loader.load(), 1200, 780);
        scene.getStylesheets().add(HelloApplication.class.getResource("/view/app.css").toExternalForm());

        Stage stage = (Stage) usernameField.getScene().getWindow();
        stage.setTitle("Pet Shop Manager");
        stage.setScene(scene);
        stage.show();
    }
}
