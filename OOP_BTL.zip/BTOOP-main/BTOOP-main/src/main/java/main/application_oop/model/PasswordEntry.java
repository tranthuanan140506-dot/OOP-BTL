package main.application_oop.model;

public class PasswordEntry {
    private String serviceName;
    private String username;
    private String password;
    private String note;

    public PasswordEntry() {
    }

    public PasswordEntry(String serviceName, String username, String password, String note) {
        this.serviceName = serviceName;
        this.username = username;
        this.password = password;
        this.note = note;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}