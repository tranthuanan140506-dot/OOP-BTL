package main.application_oop.model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class PasswordRepository {
    private final ObservableList<PasswordEntry> data = FXCollections.observableArrayList();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    private final Path filePath = Paths.get(System.getProperty("user.dir"), "data", "passwords.json");
    private final Type listType = new TypeToken<List<PasswordEntry>>() {}.getType();

    public PasswordRepository() {
        loadFromFile();
    }

    public ObservableList<PasswordEntry> findAll() {
        return data;
    }

    public void add(PasswordEntry entry) {
        data.add(entry);
        saveToFile();
    }

    public void remove(PasswordEntry entry) {
        data.remove(entry);
        saveToFile();
    }

    public void saveToFile() {
        try {
            Files.createDirectories(filePath.getParent());
            Files.writeString(filePath, gson.toJson(data));
        } catch (IOException e) {
            throw new RuntimeException("Không thể lưu dữ liệu JSON", e);
        }
    }

    private void loadFromFile() {
        try {
            if (!Files.exists(filePath)) {
                Files.createDirectories(filePath.getParent());
                Files.writeString(filePath, "[]");
                return;
            }

            String json = Files.readString(filePath);
            if (json == null || json.isBlank()) {
                return;
            }

            List<PasswordEntry> list = gson.fromJson(json, listType);
            if (list != null) {
                data.setAll(list);
            }
        } catch (IOException e) {
            throw new RuntimeException("Không thể đọc dữ liệu JSON", e);
        } catch (Exception e) {
            throw new RuntimeException("Dữ liệu JSON không hợp lệ", e);
        }
    }
}