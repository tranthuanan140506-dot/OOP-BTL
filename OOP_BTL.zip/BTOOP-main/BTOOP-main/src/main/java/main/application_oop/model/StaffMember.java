package main.application_oop.model;

public class StaffMember {
    private String id;
    private String name;
    private String role;
    private String shift;
    private String phone;

    public StaffMember(String id, String name, String role, String shift, String phone) {
        this.id = id;
        this.name = name;
        this.role = role;
        this.shift = shift;
        this.phone = phone;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
