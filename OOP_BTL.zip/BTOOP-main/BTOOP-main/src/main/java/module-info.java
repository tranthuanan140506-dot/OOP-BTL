module main.application_oop {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;

    opens main.application_oop to javafx.fxml;
    opens main.application_oop.controller to javafx.fxml;
    opens main.application_oop.model to javafx.base, com.google.gson;

    exports main.application_oop;
}